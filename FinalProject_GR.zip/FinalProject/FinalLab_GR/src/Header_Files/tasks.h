/*
 * tasks.h
 *
 *  Created on: Feb 4, 2022
 *      Author: GR
 */

#ifndef SRC_HEADER_FILES_TASKS_H_
#define SRC_HEADER_FILES_TASKS_H_

#include "gpio.h"
#include "capsense.h"
#include "os.h"
#include "fifo.h"
#include <stdio.h>

extern OS_FLAG_GRP  VEHICLE_DATA_FLAG_GROUP;
extern OS_FLAG_GRP  ALERT_EVENT_FLAG_GROUP;
extern OS_SEM Speed_Semaphore;
extern OS_SEM Direction_Semaphore;
extern OS_TMR  Direction_Timer;
extern OS_SEM Monitor_Semaphore;
extern OS_TMR  Monitor_Timer;
extern OS_SEM LCD_Semaphore;
extern OS_TMR  LCD_Timer;
extern OS_MUTEX SpeedMutex;
extern OS_MUTEX DirectionMutex;

typedef struct button_state {
    CPU_INT08U   type;
    CPU_INT08U  *p_buf;
} BUTTON_STATE;


//Vehicle Direction Task info
#define PLATFORM_DIRECTION_TASK_STACK_SIZE      128

#define PLATFORM_DIRECTION_TASK_PRIO            20

//LCD Display Task info
#define LCD_DISPLAY_TASK_STACK_SIZE      128

#define LCD_DISPLAY_TASK_PRIO            20



//Speed setpoint Task info
#define SPEED_SETPOINT_TASK_STACK_SIZE      128

#define SPEED_SETPOINT_TASK_PRIO            21

//Vehicle Monitor Task Info
#define VEHICLE_MONITOR_TASK_STACK_SIZE      128

#define VEHICLE_MONITOR_TASK_PRIO            22

//LED Task Info
#define LED_TASK_STACK_SIZE      128

#define LED_TASK_PRIO            22



#define IDLE_TASK_STACK_SIZE      96

#define IDLE_TASK_PRIO            24

typedef enum{
  Vehicle_Speed = 1,
  Vehicle_Direction = 2,
  Alert_Flag = 4
}event_flag_type;



//Sense Task info
#define SENSE_TASK_STACK_SIZE      128

#define SENSE_TASK_PRIO            20



//Button Task info
#define BUTTON_TASK_STACK_SIZE      128

#define BUTTON_TASK_PRIO            21

//LED Task Info
#define LED_TASK_STACK_SIZE      128

#define LED_TASK_PRIO            22



#define IDLE_TASK_STACK_SIZE      96

#define IDLE_TASK_PRIO            24

typedef enum{
  Button0_Event = 1,
  Button1_Event = 2
}event_flag_type;


void tasks_init(void);
void  Event_TimerCallback();
void tasks_init(void);
void Direction_TimerCallback();
void Monitor_TimerCallback();
void LCD_TimerCallback();

#endif /* SRC_HEADER_FILES_TASKS_H_ */
