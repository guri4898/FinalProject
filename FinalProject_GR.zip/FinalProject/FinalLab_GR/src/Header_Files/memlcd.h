/*
 * memlcd.h
 *
 *  Created on: Mar 17, 2022
 *      Author: GR
 */

#ifndef SRC_HEADER_FILES_MEMLCD_H_
#define SRC_HEADER_FILES_MEMLCD_H_

#include "gpio.h"

#endif /* SRC_HEADER_FILES_MEMLCD_H_ */
