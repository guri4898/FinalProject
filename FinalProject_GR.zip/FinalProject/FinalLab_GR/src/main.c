#include <stdint.h>
#include <stdbool.h>
#include "app.h"
#include "cpu.h"
#include "cmu.h"
#include "em_chip.h"
#include "os.h"
#include "bsp_os.h"
#include "os_trace.h"
#include "em_emu.h"
#include "capsense.h"
#include "tasks.h"




/***************************************************************************//**
 * @brief
 *   Read capacitive touch sensor and drive the LEDs based on the reading every 100ms.
 ******************************************************************************/



enum BUTTONBITMASK {BUTTON0, BUTTON1};




/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/

void GPIO_EVEN_IRQHandler(void)
{
  RTOS_ERR err;
  uint32_t int_flag;
  OS_SEM_CTR  ctr;
  int_flag = GPIO->IF & GPIO->IEN;
  GPIO->IFC = int_flag;
  push(true);
  ctr = OSSemPost(&Speed_Semaphore,    /* Pointer to user-allocated semaphore.    */
                 OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
                 &err);

}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/

void GPIO_ODD_IRQHandler(void)
{
  RTOS_ERR err;
  uint32_t int_flag;
  OS_SEM_CTR  ctr;
  int_flag = GPIO->IF & GPIO->IEN;
  GPIO->IFC = int_flag;
  push(false);
  ctr = OSSemPost(&Speed_Semaphore,    /* Pointer to user-allocated semaphore.    */
                OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
                &err);
}


int main(void)
{
  EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
  CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;

  /* Chip errata */
  CHIP_Init();

  /* Init DCDC regulator and HFXO with kit specific parameters */
  /* Init DCDC regulator and HFXO with kit specific parameters */
  /* Initialize DCDC. Always start in low-noise mode. */
  EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
  EMU_DCDCInit(&dcdcInit);
  em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
  EMU_EM23Init(&em23Init);
  CMU_HFXOInit(&hfxoInit);

  /* Switch HFCLK to HFRCO and disable HFRCO */
  CMU_OscillatorEnable(cmuOsc_HFRCO, true, true);
  CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
  CMU_OscillatorEnable(cmuOsc_HFXO, false, false);



  cmu_open();
  CAPSENSE_Init();

  BSP_SystemInit();                                           /* Initialize System.                                   */
  RTOS_ERR  err;

  CPU_Init();
  OS_TRACE_INIT();
  OSInit(&err);                                               /* Initialize the Kernel.                               */
  /*   Check error code.                                  */
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  app_init();


  NVIC_EnableIRQ(GPIO_EVEN_IRQn);
  NVIC_EnableIRQ(GPIO_ODD_IRQn);

  GPIO_IntConfig(BUTTON1_port, BUTTON1_pin, true, true, true);
  GPIO_IntConfig(BUTTON0_port, BUTTON0_pin, true, true, true);

  OSStart(&err);                                              /* Start the kernel.                                    */
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

