/*
 * tasks.c
 *
 *  Created on: Feb 4, 2022
 *      Author: GR
 */
#include "sl_simple_led.h"
#include "sl_simple_led_instances.h"
#include "os.h"
#include "em_emu.h"
#include "tasks.h"

static bool BUTTON0_Pressed;
static bool BUTTON1_Pressed;
static uint32_t capsense_zone;

static OS_TCB button_tcb;
static CPU_STK button_stack[BUTTON_TASK_STACK_SIZE];

static OS_TCB led_tcb;
static CPU_STK led_stack[LED_TASK_STACK_SIZE];

static OS_TCB sense_tcb;
static CPU_STK sense_stack[SENSE_TASK_STACK_SIZE];

static OS_TCB idle_tcb;
static CPU_STK idle_stack[IDLE_TASK_STACK_SIZE];

static void idle_task(void *arg);

static void button_task(void *arg);

static void sense_task(void *arg);

static void toggle_leds_task(void *arg);

static bool local_capsense_pad0_touched;
static bool local_capsense_pad1_touched;
static bool local_capsense_pad2_touched;
static bool local_capsense_pad3_touched;
static bool local_button1_pressed;
static bool local_button0_pressed;


enum{
  BUTTON0_IS_PRESSED = 1, //equal to 0
  BUTTON0_INFO_IS_PRESENT = 2, //equal to 1
  BUTTON1_IS_PRESSED = 4, //equal to 2
  BUTTON1_INFO_IS_PRESENT = 8, //equal to 3
  PAD3_IS_TOUCHED = 16, //equal to 4
  PAD2_IS_TOUCHED = 32, //equal to 5
  PAD1_IS_TOUCHED = 64, //equal to 6
  PAD0_IS_TOUCHED = 128, //equal to 7
  CAPSENSE_INFO_PRESENT = 256 //equal to 8
};


OS_FLAG_GRP  button_flag_group;
OS_TMR  Event_Timer;
OS_Q  Event_MessageQ;
OS_SEM Event_Semaphore;

static uint32_t next;
static uint32_t prev = 0;

static OS_TCB speed_setpoint_tcb;
static CPU_STK speed_setpoint_stack[SPEED_SETPOINT_TASK_STACK_SIZE];

static OS_TCB led_tcb;
static CPU_STK led_stack[LED_TASK_STACK_SIZE];

static OS_TCB platform_direction_tcb;
static CPU_STK platform_direction_stack[PLATFORM_DIRECTION_TASK_STACK_SIZE];

static OS_TCB lcd_display_tcb;
static CPU_STK lcd_display_stack[LCD_DISPLAY_TASK_STACK_SIZE];

static OS_TCB idle_tcb;
static CPU_STK idle_stack[IDLE_TASK_STACK_SIZE];

static void idle_task(void *arg);

static void speed_setpoint_task(void *arg);

static void platform_direction_task(void *arg);

static void lcd_display_task(void *arg);

static void toggle_leds_task(void *arg);


struct direction_t{
  bool left;
  bool right;
  char direction[20];
} direction;

struct speed_t{
  uint32_t speed;
  bool increment;
  bool decrement;
} speed;

static uint32_t start_speed = 0;
static char text[20];

OS_SEM Speed_Semaphore;
OS_SEM Direction_Semaphore;
OS_TMR  Direction_Timer;
OS_SEM Monitor_Semaphore;
OS_TMR  Monitor_Timer;
OS_SEM LCD_Semaphore;
OS_TMR  LCD_Timer;
OS_MUTEX SpeedMutex;
OS_MUTEX DirectionMutex;





void Direction_TimerCallback (){
  RTOS_ERR err;
  OS_SEM_CTR  ctr;
  ctr = OSSemPost(&Direction_Semaphore,    /* Pointer to user-allocated semaphore.    */
                 OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
                 &err);
}

void Monitor_TimerCallback(){
  RTOS_ERR err;
  OS_SEM_CTR  ctr;
  ctr = OSSemPost(&Monitor_Semaphore,    /* Pointer to user-allocated semaphore.    */
                 OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
                 &err);
}

void LCD_TimerCallback(){
  RTOS_ERR err;
  OS_SEM_CTR  ctr;
  ctr = OSSemPost(&LCD_Semaphore,    /* Pointer to user-allocated semaphore.    */
                 OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
                 &err);
}

void tasks_init(void)
{
  RTOS_ERR err;
  uint32_t status;

  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&glibContext);
  EFM_ASSERT(status == GLIB_OK);

  glibContext.backgroundColor = White;
  glibContext.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&glibContext);

  /* Use Narrow font */
  GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);


    // Create Speed Setpoint Task
    OSTaskCreate(&speed_setpoint_tcb,
                 "speed setpoint task",
                 speed_setpoint_task,
                 DEF_NULL,
                 SPEED_SETPOINT_TASK_PRIO,
                 &speed_setpoint_stack[0],
                 (SPEED_SETPOINT_TASK_STACK_SIZE / 10u),
                 SPEED_SETPOINT_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));




    // Create Vehicle Direction Task
    OSTaskCreate(&platform_direction_tcb,
                 "Platform Direction task",
                 platform_direction_task,
                 DEF_NULL,
                 PLATFORM_DIRECTION_TASK_PRIO,
                 &platform_direction_stack[0],
                 (PLATFORM_DIRECTION_TASK_STACK_SIZE / 10u),
                PLATFORM_DIRECTION_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


    // Create Vehicle Direction Task
    OSTaskCreate(&lcd_display_tcb,
                 "Platform Direction task",
                 lcd_display_task,
                 DEF_NULL,
                 LCD_DISPLAY_TASK_PRIO,
                 &lcd_display_stack[0],
                 (LCD_DISPLAY_TASK_STACK_SIZE / 10u),
                 LCD_DISPLAY_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


    // Create LED Task
    OSTaskCreate(&led_tcb,
                 "LEDs task",
                 toggle_leds_task,
                 DEF_NULL,
                 LED_TASK_PRIO,
                 &led_stack[0],
                 (LED_TASK_STACK_SIZE / 10u),
                 LED_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


    OSSemCreate(&Direction_Semaphore,
                   "Direction Semaphore",
                   0,
                   &err);


    OSTmrCreate(&Direction_Timer,            /*   Pointer to user-allocated timer.     */
                    "Direction Timer",           /*   Name used for debugging.             */
                     1,                  /*     100 initial delay.                   */
                     1,                  /*   100 Timer Ticks period.              */
                     OS_OPT_TMR_PERIODIC,  /*   Timer is periodic.                   */
                    &Direction_TimerCallback,    /*   Called when timer expires.           */
                     DEF_NULL,             /*   No arguments to callback.            */
                    &err);


    OSSemCreate(&Monitor_Semaphore,
                   "Monitor Semaphore",
                   0,
                   &err);


    OSTmrCreate(&Monitor_Timer,            /*   Pointer to user-allocated timer.     */
                    "Monitor Timer",           /*   Name used for debugging.             */
                     1,                  /*     100 initial delay.                   */
                     1,                  /*   100 Timer Ticks period.              */
                     OS_OPT_TMR_PERIODIC,  /*   Timer is periodic.                   */
                    &Monitor_TimerCallback,    /*   Called when timer expires.           */
                     DEF_NULL,             /*   No arguments to callback.            */
                    &err);



    OSSemCreate(&LCD_Semaphore,
                   "LCD Semaphore",
                   0,
                   &err);


    OSTmrCreate(&LCD_Timer,            /*   Pointer to user-allocated timer.     */
                    "LCD Timer",           /*   Name used for debugging.             */
                     1,                  /*     100 initial delay.                   */
                     1,                  /*   100 Timer Ticks period.              */
                     OS_OPT_TMR_PERIODIC,  /*   Timer is periodic.                   */
                    &LCD_TimerCallback,    /*   Called when timer expires.           */
                     DEF_NULL,             /*   No arguments to callback.            */
                    &err);

    OSSemCreate(&Speed_Semaphore,
                   "Speed Semaphore",
                   0,
                   &err);

    OSMutexCreate(&SpeedMutex,   /*   Pointer to user-allocated mutex.                 */
                   "Speed Mutex",  /*   Name used for debugging.                         */
                   &err);

    OSMutexCreate(&DirectionMutex,   /*   Pointer to user-allocated mutex.                 */
                   "Direction Mutex",  /*   Name used for debugging.                         */
                   &err);

    OSTaskCreate(&idle_tcb,
                 "idle task",
                 idle_task,
                 DEF_NULL,
                 IDLE_TASK_PRIO,
                 &idle_stack[0],
                 (IDLE_TASK_STACK_SIZE / 10u),
                 IDLE_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


static void button_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OS_FLAGS  flags;
    uint32_t packed9bitsdata;
    while (1)
    {
        flags = OSFlagPend(&button_flag_group,
                           Button0_Event | Button1_Event,
                           0,
                           OS_OPT_PEND_FLAG_SET_ANY |
                           OS_OPT_PEND_BLOCKING     |
                           OS_OPT_PEND_FLAG_CONSUME,
                           DEF_NULL,
                           &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        switch(flags)
        {
          case Button0_Event:
            packed9bitsdata = BUTTON0_INFO_IS_PRESENT | (GPIO_PinInGet(BUTTON0_port, BUTTON0_pin)<<0);                                  /* Send message to the waiting task.                */
            OSQPost(&Event_MessageQ,                /*   Pointer to user-allocated message queue.       */
                    packed9bitsdata,                 /*   The message is a pointer to the APP_MESSAGE.   */
                    (OS_MSG_SIZE)0,  /*   Size of the message is irrelivent.  */
                     OS_OPT_POST_FIFO,            /*   Add message at the end of the queue.           */
                    &err);
            break;

          case Button1_Event:
            packed9bitsdata = BUTTON1_INFO_IS_PRESENT | (GPIO_PinInGet(BUTTON1_port, BUTTON1_pin)<<2);                          /* Send message to the waiting task.                */
            OSQPost(&Event_MessageQ,                /*   Pointer to user-allocated message queue.       */
                    packed9bitsdata,                 /*   The message is a pointer to the APP_MESSAGE.   */
                    (OS_MSG_SIZE)0,  /*   Size of the message is irrelivent  */
                     OS_OPT_POST_FIFO,            /*   Add message at the end of the queue.           */
                    &err);
            break;

          case Button0_Event | Button1_Event:
          packed9bitsdata = BUTTON0_INFO_IS_PRESENT | (GPIO_PinInGet(BUTTON0_port, BUTTON0_pin)<<0) | BUTTON1_INFO_IS_PRESENT | (GPIO_PinInGet(BUTTON1_port, BUTTON1_pin)<<2);
          OSQPost(&Event_MessageQ,                /*   Pointer to user-allocated message queue.       */
                 packed9bitsdata,                 /*   The message is a pointer to the APP_MESSAGE.   */
                (OS_MSG_SIZE)0,  /*   Size of the message is irrelivent  */
                 OS_OPT_POST_FIFO,            /*   Add message at the end of the queue.           */
                &err);
            break;
          default:
            return;
        }

    }

}


static void toggle_leds_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    uint32_t data;
    OS_MSG_SIZE msg_size;
    RTOS_ERR err;
    while (1)
    {
        data =  (uint32_t)OSQPend(&Event_MessageQ,
                       0,
                       OS_OPT_PEND_BLOCKING,
                       &msg_size,
                       DEF_NULL,
                       &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        if(data & CAPSENSE_INFO_PRESENT){
            local_capsense_pad0_touched = data & PAD0_IS_TOUCHED;
            local_capsense_pad1_touched = data & PAD1_IS_TOUCHED;
            local_capsense_pad2_touched = data & PAD2_IS_TOUCHED;
            local_capsense_pad3_touched = data & PAD3_IS_TOUCHED;
        }
        if(data & BUTTON1_INFO_IS_PRESENT){
            local_button1_pressed = data & BUTTON1_IS_PRESSED;
        }
        if(data & BUTTON0_INFO_IS_PRESENT){
            local_button0_pressed = data & BUTTON0_IS_PRESSED;
        }
        if((local_capsense_pad0_touched == true) && (local_capsense_pad2_touched == false) && (local_capsense_pad3_touched == false)){
            capsense_zone = 0;
        }
        else if((local_capsense_pad1_touched == true) && (local_capsense_pad2_touched == false) && (local_capsense_pad3_touched == false)){
            capsense_zone = 1;
        }
        else if((local_capsense_pad2_touched == true) && (local_capsense_pad0_touched == false) && (local_capsense_pad1_touched == false)){
            capsense_zone = 2;
        }
        else if((local_capsense_pad3_touched == true) && (local_capsense_pad0_touched == false) && (local_capsense_pad1_touched == false)){
            capsense_zone = 3;
        }
        else{
            capsense_zone = 5;
        }
        if((local_button1_pressed == true) && (local_button0_pressed == false)){
            BUTTON1_Pressed = true;
        }else{
            BUTTON1_Pressed = false;
        }
        if((local_button0_pressed == true) && (local_button1_pressed == false)){
            BUTTON0_Pressed = true;
        }else{
            BUTTON0_Pressed = false;
        }
        if(BUTTON0_Pressed || (capsense_zone == 0 || capsense_zone == 1)){
            GPIO_PinOutSet(LED0_port, LED0_pin);
        }
        else{
            GPIO_PinOutClear(LED0_port, LED0_pin);
        }
        if(BUTTON1_Pressed || (capsense_zone == 2 || capsense_zone == 3)){
            GPIO_PinOutSet(LED1_port, LED1_pin);
        }
        else{
            GPIO_PinOutClear(LED1_port, LED1_pin);
        }



    }


}
static void sense_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OSTmrStart(&Event_Timer, &err);
    OS_SEM_CTR  ctr;
    uint32_t packed9bitsdata;
    while (1)
    {
        ctr = OSSemPend(&Event_Semaphore,        /* Pointer to user-allocated semaphore.    */
                  0,                 /* No time-out required  */
                  OS_OPT_PEND_BLOCKING, /* Task will block.                        */
                  DEF_NULL,             /* Timestamp is not used.                  */
                 &err);
        CAPSENSE_Sense();
        packed9bitsdata = CAPSENSE_INFO_PRESENT;
        if(CAPSENSE_getPressed(0)){
            packed9bitsdata |= (PAD0_IS_TOUCHED);
        }
        if(CAPSENSE_getPressed(1)){
            packed9bitsdata |= (PAD1_IS_TOUCHED);
        }
        if(CAPSENSE_getPressed(2)){
            packed9bitsdata |= (PAD2_IS_TOUCHED);
        }
        if(CAPSENSE_getPressed(3)){
            packed9bitsdata |= (PAD3_IS_TOUCHED);
        }
        OSQPost(&Event_MessageQ,                /*   Pointer to user-allocated message queue.       */
            packed9bitsdata,                 /*   The message is a pointer to the APP_MESSAGE.   */
            (OS_MSG_SIZE)0,  /*   Size of the message is irrelivent  */
             OS_OPT_POST_FIFO,            /*   Add message at the end of the queue.           */
            &err);
    }


}

static void idle_task(void *arg){
    PP_UNUSED_PARAM(arg);
    while(1){
        EMU_EnterEM1();
    }




static void lcd_display_task(void *arg){
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OSTmrStart(&LCD_Timer, &err);
    uint32_t total_speed = 0;
    OSMutexPend(&SpeedMutex,             /*   Pointer to user-allocated mutex.         */
                 1000,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                 OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                 DEF_NULL,              /*   Timestamp is not used.                   */
                &err);
    total_speed += speed.speed
    sprintf(text, "%d", total_speed);
    GLIB_drawStringOnLine(&glibContext,
                         text,
                         1,
                         GLIB_ALIGN_LEFT,
                         5,
                         5,
                         true);
            DMD_updateDisplay();

    OSMutexPost(&SpeedMutex,         /*   Pointer to user-allocated mutex.         */
                 OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                &err);

    GLIB_drawNumberOnLine(&glibContext,
                        direction.direction,
                         1,
                         GLIB_ALIGN_RIGHT,
                         5,
                         5,
                         true);
              DMD_updateDisplay();

    OSMutexPend(&DirectionMutex,             /*   Pointer to user-allocated mutex.         */
                 1000,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                 OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                 DEF_NULL,              /*   Timestamp is not used.                   */
                &err);
    OSMutexPost(&DirectionMutex,         /*   Pointer to user-allocated mutex.         */
                 OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                &err);

}

static void speed_setpoint_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    bool fifo_data;
    OS_SEM_CTR  ctr;
    while (1)
    {

        ctr = OSSemPend(&Speed_Semaphore,        /* Pointer to user-allocated semaphore.    */
                  0,                 /* No time-out required  */
                  OS_OPT_PEND_BLOCKING, /* Task will block.                        */
                  DEF_NULL,             /* Timestamp is not used.                  */
                 &err);

        OSMutexPend(&SpeedMutex,             /*   Pointer to user-allocated mutex.         */
                         1000,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                         DEF_NULL,              /*   Timestamp is not used.                   */
                        &err);
        CORE_DECLARE_IRQ_STATE;
        CORE_ENTER_CRITICAL();
        fifo_data = peek();
        pop();
        CORE_EXIT_CRITICAL();


        if(fifo_data)
        {
            speed.increment = true;
            speed.decrement = false;
        }
        else
        {
            speed.decrement = true;
            speed.increment = false;
        }
        OSMutexPost(&SpeedMutex,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                     &err);

        OSFlagPost(&VEHICLE_DATA_FLAG_GROUP,             /*   Pointer to user-allocated event flag.    */
              VEHICLE_SPEED_FLAG,            /*   Application Flag A bitmask.              */
              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
              &err);


    }

}



}
static void platform_direction_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OS_SEM_CTR  ctr;
    OSTmrStart(&Direction_Timer, &err);
    while (1)
    {
        ctr = OSSemPend(&Direction_Semaphore,        /* Pointer to user-allocated semaphore.    */
                     0,                 /* No time-out required  */
                     OS_OPT_PEND_BLOCKING, /* Task will block.                        */
                     DEF_NULL,             /* Timestamp is not used.                  */
                    &err);
        OSMutexPend(&DirectionMutex,             /*   Pointer to user-allocated mutex.         */
                     1000,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        direction.hard_left = false;
        direction.left = false;
        direction.right = false;
        direction.hard_right = false;
        CAPSENSE_Sense();
        if(CAPSENSE_getPressed(0)){
            direction.is_turning = true;
            direction.hard_left = true;
            direction.left = false;
            direction.right = false;
            direction.hard_right = false;
            next = 1;
            direction.direction = "hard left";

        }
        if(CAPSENSE_getPressed(1)){
            direction.is_turning = true;
            direction.hard_left = false;
            direction.left = true;
            direction.right = false;
            direction.hard_right = false;
            next = 2;
            direction.direction = "left";
        }
        if(CAPSENSE_getPressed(2)){
            direction.is_turning = true;
            direction.hard_left = false;
            direction.left = false;
            direction.right = true;
            direction.hard_right = false;
            next = 3;
            direction.direction = "right";
        }
        if(CAPSENSE_getPressed(3)){
            direction.is_turning = true;
            direction.hard_left = false;
            direction.left = false;
            direction.right = false;
            direction.hard_right = true;
            next = 4;
            direction.direction = "hard right";
        }

        if(prev == next){
            direction.count++;
        }
        else{
            prev = next;
            direction.count = 0;
        }

        OSMutexPost(&DirectionMutex,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

          OSFlagPost(&VEHICLE_DATA_FLAG_GROUP,             /*   Pointer to user-allocated event flag.    */
               VEHICLE_DIRECTION_FLAG,            /*   Application Flag A bitmask.              */
               OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
               &err);
    }


}

static void idle_task(void *arg){
    PP_UNUSED_PARAM(arg);
    while(1){
        EMU_EnterEM1();
    }


}

