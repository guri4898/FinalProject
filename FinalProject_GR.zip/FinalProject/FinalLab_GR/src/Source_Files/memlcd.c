/*
 * memlcd.c
 *
 *  Created on: Mar 17, 2022
 *      Author: GR
 */


