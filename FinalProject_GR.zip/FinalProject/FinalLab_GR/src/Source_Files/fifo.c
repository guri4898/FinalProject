/*
 * fifo.c
 *
 *  Created on: Mar 17, 2022
 *      Author: GR
 */
#include <stdio.h>
#include <stdlib.h>
#include "fifo.h"

static struct node_t** head = NULL;

struct node_t* create_new_node(bool pressed) {
    struct node_t *newNode = malloc(sizeof(struct node_t));
    newNode->Button1_Pressed = pressed;
    newNode->next = NULL;
    return newNode;
}

bool peek() {
    if(!is_empty(head))
     {
         while((*head)->next != NULL){
             (*head) = (*head)->next;
         }
         return (*head)->Button1_Pressed;
     }
    else
        exit(1);
    return NULL;
}

void pop() {
    if((*head) != NULL){
        (*head) = (*head)->next;
    }
}

void push(bool pressed) {
    if((*head) == NULL){
        (*head)->Button1_Pressed = pressed;
    }
    while((*head)->next != NULL)
    {
        (*head) = (*head)->next;
    }
    (*head)->next = create_new_node(pressed);
}

int is_empty(struct node_t** head) {
    return (head == NULL);
}




